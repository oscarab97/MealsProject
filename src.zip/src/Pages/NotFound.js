function NotFound () {
   return( <div>
        <h1>Hola</h1>
    </div>
   )
}
export default NotFound