const initialState = {
	cart: [],
	isOpen: false,
	meal: {},
};

export default initialState;